<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_GB">
<context>
    <name>MainWidget</name>
    <message>
        <location filename="../../UI/mainwidget.ui" line="14"/>
        <source>UniFlow工具集</source>
        <translation type="unfinished">UniFlow ToolSet</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="30"/>
        <source>首页</source>
        <translation type="unfinished">Home</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="48"/>
        <source> 控制器</source>
        <translation type="unfinished">Controller</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="66"/>
        <source> 检测机</source>
        <translation type="unfinished">Detector</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="84"/>
        <source>溯源</source>
        <translation type="unfinished">Analytics</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="102"/>
        <source>系统设置</source>
        <translation type="unfinished">System Setting</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="126"/>
        <source>系统参数</source>
        <translation type="unfinished">System parameter</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="138"/>
        <source>随系统启动</source>
        <translation type="unfinished">Startup when system boots</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="151"/>
        <source>启动方式：</source>
        <translation type="unfinished">Startup way:</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="164"/>
        <source>退出方式：</source>
        <translation type="unfinished">Quit way:</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="177"/>
        <source>退出运行</source>
        <translation type="unfinished">Quit</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="196"/>
        <source>最小化到托盘</source>
        <translation type="unfinished">Minimize to system tray</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="212"/>
        <source>英语</source>
        <translation type="unfinished">English</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="228"/>
        <source>切换语言：</source>
        <translation type="unfinished">Switch language:</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="241"/>
        <source>中文</source>
        <translation type="unfinished">Chinese</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="255"/>
        <source> 关于</source>
        <translation type="unfinished">About</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="279"/>
        <source>版本：0.1</source>
        <translation type="unfinished">Version: 0.1</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="292"/>
        <source>作者：王冲</source>
        <translation type="unfinished">Author: wangchong</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="305"/>
        <source>邮箱：wangchong@msn.com</source>
        <translation type="unfinished">E-mail:wangchong@msn.com</translation>
    </message>
    <message>
        <location filename="../../UI/mainwidget.ui" line="318"/>
        <source>构建：2020-3-2 21:00:00</source>
        <translation type="unfinished">Build: 2020-3-2 21:00</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../Source/Main/Source/main.cpp" line="14"/>
        <source>Systray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../Source/Main/Source/main.cpp" line="15"/>
        <source>I couldn&apos;t detect any system tray on this system.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SysTray</name>
    <message>
        <location filename="../../../Source/Utils/System/Source/systray.cpp" line="20"/>
        <source>&amp;Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../Source/Utils/System/Source/systray.cpp" line="23"/>
        <source>&amp;Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../Source/Utils/System/Source/systray.cpp" line="26"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../Source/Utils/System/Source/systray.cpp" line="79"/>
        <source>Systray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../Source/Utils/System/Source/systray.cpp" line="80"/>
        <source>Sorry, I already gave what help I could.
Maybe you should try asking a human?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../Source/Utils/System/Source/systray.cpp" line="86"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../Source/Utils/System/Source/systray.cpp" line="87"/>
        <source>There is a new message!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
