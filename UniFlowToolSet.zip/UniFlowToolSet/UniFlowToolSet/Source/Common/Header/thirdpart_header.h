#ifndef THIRDPART_HEADER_H
#define THIRDPART_HEADER_H

#include "Source/ThirdPart/Source/qtsingleapplication/src/QtSingleApplication"

#endif // THIRDPART_HEADER_H
