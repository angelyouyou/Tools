#pragma once

#include "sys_header.h"

#define UI_RES_FONT_DEFAULT_SIZE    9
#define UI_RES_FONT_DEFAULT_STYLE   "Arial"

#define UI_RES_ICON_DEFAULT_APP ":/app/icons/icons/Design.png"


#define UI_RES_STRING_DEFAULT_SYSTRAY_TIP tr("TIPS")
#define UI_RES_STRING_DEFAULT_SYSTRAY_MENTU_MIN tr("&Minimize")
#define UI_RES_STRING_DEFAULT_SYSTRAY_MENTU_QUIT tr("&Quit")
#define UI_RES_STRING_DEFAULT_SYSTRAY_MENTU_RESTORE tr("&Restore")
