#include "Source/Pages/Header/mainwidget.h"
#include "Source/Common/Header/common.h"

int main(int argc, char *argv[])
{
    QtSingleApplication app("UniFlowToolSet", argc, argv);
    if (app.isRunning())
    {
        app.sendMessage("raise_window_noop");
        return EXIT_SUCCESS;
    }

    if (!QSystemTrayIcon::isSystemTrayAvailable()) {
        QMessageBox::critical(nullptr, QObject::tr("Systray"),
                              QObject::tr("I couldn't detect any system tray "
                                          "on this system."));
        return 1;
    }

    MainWidget win;
    win.setWindowFlags(win.windowFlags() &~ Qt::WindowMaximizeButtonHint);

    SysTray systray((QWidget*)&win);
    systray.show("tip", "msg");

    win.show();

    return app.exec();
}
