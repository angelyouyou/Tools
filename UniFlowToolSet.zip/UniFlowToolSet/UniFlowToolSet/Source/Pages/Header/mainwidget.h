#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWidget; }
QT_END_NAMESPACE

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    MainWidget(QWidget *parent = nullptr);
    ~MainWidget();

private slots:
    void on_radioButton_English_clicked();

    void on_radioButton_Chinese_clicked();

    void on_checkBox_stateChanged(int checkState);

    void on_horizontalSlider_Opacity_valueChanged(int value);

private:
    Ui::MainWidget *ui;
};
#endif // MAINWIDGET_H
