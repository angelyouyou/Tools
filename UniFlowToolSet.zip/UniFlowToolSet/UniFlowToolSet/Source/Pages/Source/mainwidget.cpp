#include "Source/Pages/Header/mainwidget.h"
#include "ui_mainwidget.h"
#include "Source/Common/Header/common.h"

MainWidget::MainWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainWidget)
{
    ui->setupUi(this);
}

MainWidget::~MainWidget()
{
    delete ui;
}

void MainWidget::on_radioButton_English_clicked()
{
    //QString locale = QLocale::system().name();
    QTranslator translator;
    if (translator.load(":/lang/Lang_en_GB.qm")) {
        qApp->installTranslator(&translator);
        this->ui->retranslateUi(this);
    }
}

void MainWidget::on_radioButton_Chinese_clicked()
{
    QTranslator translator;
    if (translator.load(":/lang/Lang_zh_CN.qm")) {
        qApp->installTranslator(&translator);
        this->ui->retranslateUi(this);
    }
}

void MainWidget::on_checkBox_stateChanged(int checkState)
{
    RegisterUtil utils;
    if (checkState == Qt::Checked) {
        utils.setAutoRun(true);
    } else if (checkState == Qt::Unchecked) {
        utils.setAutoRun(false);
    } else {
        return;
    }
}

void MainWidget::on_horizontalSlider_Opacity_valueChanged(int value)
{
    setWindowOpacity((100-value)/100);
}
