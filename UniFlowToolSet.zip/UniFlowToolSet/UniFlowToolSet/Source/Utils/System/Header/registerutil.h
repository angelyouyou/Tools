#ifndef REGISTERUTIL_H
#define REGISTERUTIL_H

#include <QObject>

#define REG_RUN "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"

class RegisterUtil : public QObject
{
    Q_OBJECT
public:
    explicit RegisterUtil(QObject *parent = nullptr);

signals:
public:
    void setAutoRun(bool isAutoRun);
};

#endif // REGISTERUTIL_H
