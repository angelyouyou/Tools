/********************************************************************************
** Form generated from reading UI file 'mainwidget.ui'
**
** Created by: Qt User Interface Compiler version 6.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWIDGET_H
#define UI_MAINWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWidget
{
public:
    QTabWidget *tabWidget;
    QWidget *tab_Home;
    QGroupBox *groupBox_Home;
    QWidget *tab_Controller;
    QGroupBox *groupBox_Controller;
    QWidget *tab_Detector;
    QGroupBox *groupBox_Detector;
    QWidget *tab_Analytics;
    QGroupBox *groupBox_Analytics;
    QWidget *tab_SysSetting;
    QGroupBox *groupBox_SysSetting;
    QGroupBox *groupBox_SysSetting_2;
    QCheckBox *checkBox;
    QLabel *label_RunAtBoot;
    QLabel *label_QuitWay;
    QRadioButton *radioButton_QuitRun;
    QRadioButton *radioButton_Min2SysTray;
    QRadioButton *radioButton_English;
    QLabel *label_Language;
    QRadioButton *radioButton_Chinese;
    QLabel *label_Language_2;
    QSlider *horizontalSlider_Opacity;
    QWidget *tab_About;
    QGroupBox *groupBox_About;
    QLabel *label_Version;
    QLabel *label_Author;
    QLabel *label_Email;
    QLabel *label_Build;

    void setupUi(QWidget *MainWidget)
    {
        if (MainWidget->objectName().isEmpty())
            MainWidget->setObjectName(QString::fromUtf8("MainWidget"));
        MainWidget->resize(800, 600);
        tabWidget = new QTabWidget(MainWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(10, 0, 781, 591));
        tab_Home = new QWidget();
        tab_Home->setObjectName(QString::fromUtf8("tab_Home"));
        groupBox_Home = new QGroupBox(tab_Home);
        groupBox_Home->setObjectName(QString::fromUtf8("groupBox_Home"));
        groupBox_Home->setGeometry(QRect(10, 10, 761, 541));
        tabWidget->addTab(tab_Home, QString());
        tab_Controller = new QWidget();
        tab_Controller->setObjectName(QString::fromUtf8("tab_Controller"));
        groupBox_Controller = new QGroupBox(tab_Controller);
        groupBox_Controller->setObjectName(QString::fromUtf8("groupBox_Controller"));
        groupBox_Controller->setGeometry(QRect(10, 10, 751, 541));
        tabWidget->addTab(tab_Controller, QString());
        tab_Detector = new QWidget();
        tab_Detector->setObjectName(QString::fromUtf8("tab_Detector"));
        groupBox_Detector = new QGroupBox(tab_Detector);
        groupBox_Detector->setObjectName(QString::fromUtf8("groupBox_Detector"));
        groupBox_Detector->setGeometry(QRect(10, 10, 751, 541));
        tabWidget->addTab(tab_Detector, QString());
        tab_Analytics = new QWidget();
        tab_Analytics->setObjectName(QString::fromUtf8("tab_Analytics"));
        groupBox_Analytics = new QGroupBox(tab_Analytics);
        groupBox_Analytics->setObjectName(QString::fromUtf8("groupBox_Analytics"));
        groupBox_Analytics->setGeometry(QRect(10, 10, 751, 541));
        tabWidget->addTab(tab_Analytics, QString());
        tab_SysSetting = new QWidget();
        tab_SysSetting->setObjectName(QString::fromUtf8("tab_SysSetting"));
        groupBox_SysSetting = new QGroupBox(tab_SysSetting);
        groupBox_SysSetting->setObjectName(QString::fromUtf8("groupBox_SysSetting"));
        groupBox_SysSetting->setGeometry(QRect(10, 10, 751, 541));
        groupBox_SysSetting_2 = new QGroupBox(groupBox_SysSetting);
        groupBox_SysSetting_2->setObjectName(QString::fromUtf8("groupBox_SysSetting_2"));
        groupBox_SysSetting_2->setGeometry(QRect(10, 10, 731, 201));
        checkBox = new QCheckBox(groupBox_SysSetting_2);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(120, 40, 171, 18));
        label_RunAtBoot = new QLabel(groupBox_SysSetting_2);
        label_RunAtBoot->setObjectName(QString::fromUtf8("label_RunAtBoot"));
        label_RunAtBoot->setGeometry(QRect(10, 40, 81, 16));
        label_QuitWay = new QLabel(groupBox_SysSetting_2);
        label_QuitWay->setObjectName(QString::fromUtf8("label_QuitWay"));
        label_QuitWay->setGeometry(QRect(10, 80, 71, 20));
        radioButton_QuitRun = new QRadioButton(groupBox_SysSetting_2);
        radioButton_QuitRun->setObjectName(QString::fromUtf8("radioButton_QuitRun"));
        radioButton_QuitRun->setGeometry(QRect(120, 80, 71, 18));
        radioButton_QuitRun->setChecked(false);
        radioButton_QuitRun->setAutoRepeat(false);
        radioButton_Min2SysTray = new QRadioButton(groupBox_SysSetting_2);
        radioButton_Min2SysTray->setObjectName(QString::fromUtf8("radioButton_Min2SysTray"));
        radioButton_Min2SysTray->setGeometry(QRect(210, 80, 131, 18));
        radioButton_Min2SysTray->setChecked(false);
        radioButton_English = new QRadioButton(groupBox_SysSetting_2);
        radioButton_English->setObjectName(QString::fromUtf8("radioButton_English"));
        radioButton_English->setGeometry(QRect(210, 120, 91, 18));
        radioButton_English->setChecked(false);
        label_Language = new QLabel(groupBox_SysSetting_2);
        label_Language->setObjectName(QString::fromUtf8("label_Language"));
        label_Language->setGeometry(QRect(10, 120, 111, 20));
        radioButton_Chinese = new QRadioButton(groupBox_SysSetting_2);
        radioButton_Chinese->setObjectName(QString::fromUtf8("radioButton_Chinese"));
        radioButton_Chinese->setGeometry(QRect(120, 120, 71, 18));
        radioButton_Chinese->setChecked(true);
        radioButton_Chinese->setAutoRepeat(false);
        label_Language_2 = new QLabel(groupBox_SysSetting_2);
        label_Language_2->setObjectName(QString::fromUtf8("label_Language_2"));
        label_Language_2->setGeometry(QRect(10, 160, 111, 20));
        horizontalSlider_Opacity = new QSlider(groupBox_SysSetting_2);
        horizontalSlider_Opacity->setObjectName(QString::fromUtf8("horizontalSlider_Opacity"));
        horizontalSlider_Opacity->setGeometry(QRect(120, 160, 160, 16));
        horizontalSlider_Opacity->setMouseTracking(true);
        horizontalSlider_Opacity->setTabletTracking(true);
        horizontalSlider_Opacity->setMinimum(0);
        horizontalSlider_Opacity->setMaximum(90);
        horizontalSlider_Opacity->setSingleStep(10);
        horizontalSlider_Opacity->setOrientation(Qt::Horizontal);
        horizontalSlider_Opacity->setInvertedControls(false);
        horizontalSlider_Opacity->setTickPosition(QSlider::TicksBothSides);
        tabWidget->addTab(tab_SysSetting, QString());
        tab_About = new QWidget();
        tab_About->setObjectName(QString::fromUtf8("tab_About"));
        groupBox_About = new QGroupBox(tab_About);
        groupBox_About->setObjectName(QString::fromUtf8("groupBox_About"));
        groupBox_About->setGeometry(QRect(10, 10, 751, 541));
        label_Version = new QLabel(groupBox_About);
        label_Version->setObjectName(QString::fromUtf8("label_Version"));
        label_Version->setGeometry(QRect(20, 20, 71, 16));
        label_Author = new QLabel(groupBox_About);
        label_Author->setObjectName(QString::fromUtf8("label_Author"));
        label_Author->setGeometry(QRect(20, 80, 141, 20));
        label_Email = new QLabel(groupBox_About);
        label_Email->setObjectName(QString::fromUtf8("label_Email"));
        label_Email->setGeometry(QRect(20, 110, 181, 16));
        label_Build = new QLabel(groupBox_About);
        label_Build->setObjectName(QString::fromUtf8("label_Build"));
        label_Build->setGeometry(QRect(20, 50, 181, 16));
        tabWidget->addTab(tab_About, QString());

        retranslateUi(MainWidget);

        tabWidget->setCurrentIndex(4);


        QMetaObject::connectSlotsByName(MainWidget);
    } // setupUi

    void retranslateUi(QWidget *MainWidget)
    {
        MainWidget->setWindowTitle(QCoreApplication::translate("MainWidget", "UniFlow\345\267\245\345\205\267\351\233\206", nullptr));
        groupBox_Home->setTitle(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_Home), QCoreApplication::translate("MainWidget", "\351\246\226\351\241\265", nullptr));
        groupBox_Controller->setTitle(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_Controller), QCoreApplication::translate("MainWidget", " \346\216\247\345\210\266\345\231\250", nullptr));
        groupBox_Detector->setTitle(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_Detector), QCoreApplication::translate("MainWidget", " \346\243\200\346\265\213\346\234\272", nullptr));
        groupBox_Analytics->setTitle(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_Analytics), QCoreApplication::translate("MainWidget", "\346\272\257\346\272\220", nullptr));
        groupBox_SysSetting->setTitle(QString());
        groupBox_SysSetting_2->setTitle(QCoreApplication::translate("MainWidget", "\347\263\273\347\273\237\345\217\202\346\225\260", nullptr));
        checkBox->setText(QCoreApplication::translate("MainWidget", "\351\232\217\347\263\273\347\273\237\345\220\257\345\212\250", nullptr));
        label_RunAtBoot->setText(QCoreApplication::translate("MainWidget", "\345\220\257\345\212\250\346\226\271\345\274\217\357\274\232", nullptr));
        label_QuitWay->setText(QCoreApplication::translate("MainWidget", "\351\200\200\345\207\272\346\226\271\345\274\217\357\274\232", nullptr));
        radioButton_QuitRun->setText(QCoreApplication::translate("MainWidget", "\351\200\200\345\207\272\350\277\220\350\241\214", nullptr));
        radioButton_Min2SysTray->setText(QCoreApplication::translate("MainWidget", "\346\234\200\345\260\217\345\214\226\345\210\260\346\211\230\347\233\230", nullptr));
        radioButton_English->setText(QCoreApplication::translate("MainWidget", "\350\213\261\350\257\255", nullptr));
        label_Language->setText(QCoreApplication::translate("MainWidget", "\345\210\207\346\215\242\350\257\255\350\250\200\357\274\232", nullptr));
        radioButton_Chinese->setText(QCoreApplication::translate("MainWidget", "\344\270\255\346\226\207", nullptr));
        label_Language_2->setText(QCoreApplication::translate("MainWidget", "\347\252\227\345\217\243\351\200\217\346\230\216\357\274\232", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_SysSetting), QCoreApplication::translate("MainWidget", "\347\263\273\347\273\237\350\256\276\347\275\256", nullptr));
        groupBox_About->setTitle(QString());
        label_Version->setText(QCoreApplication::translate("MainWidget", "\347\211\210\346\234\254\357\274\2320.1", nullptr));
        label_Author->setText(QCoreApplication::translate("MainWidget", "\344\275\234\350\200\205\357\274\232\347\216\213\345\206\262", nullptr));
        label_Email->setText(QCoreApplication::translate("MainWidget", "\351\202\256\347\256\261\357\274\232wangchong@msn.com", nullptr));
        label_Build->setText(QCoreApplication::translate("MainWidget", "\346\236\204\345\273\272\357\274\2322020-3-2 21:00:00", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_About), QCoreApplication::translate("MainWidget", " \345\205\263\344\272\216", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWidget: public Ui_MainWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWIDGET_H
